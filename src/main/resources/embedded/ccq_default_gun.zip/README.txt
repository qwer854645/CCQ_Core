CCQ 精简枪包 (ccq_default_gun)
================================

整合包：Create Craft & Quiet
命名空间：tacz（资源 ID 保持不变，以兼容第三方枪包）

内容
----
- tacz:12g 弹药（配方、模型、贴图、弹壳）
- tacz:flash/common_muzzle_flash（Create Armorer 枪口焰）
- tacz:default_state_machine.lua（第三方枪包动画状态机）

已移除：原版 TACZ 默认枪包中的全部枪械、配件、工作台等。

许可证
------
本包所含 TACZ 默认枪包素材版权归 TACZ Dev Team 所有，
遵循 Creative Commons CC BY-NC-ND 4.0。

详见 LICENSE 与 NOTICE。

维护
----
.lua 与 .png 须从 tacz 模组 jar 以二进制原样提取，
不可用 PowerShell Set-Content 保存（会写入 UTF-8 BOM，导致 Lua 解析失败）。

修复脚本（路径已更新为 ccq_default_gun）：
- M:\others\logs\fix-tacz-default-state-machine.ps1
- M:\others\logs\fix-tacz-default-shared-assets.ps1

放入整合包：置于实例 tacz/ 目录下作为文件夹加载。
